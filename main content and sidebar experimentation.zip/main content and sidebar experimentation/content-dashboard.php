<!-- dashboard.php -->
<h1>Dashboard</h1>
<p>Welcome to your dashboard. Here you can view your summary and quick stats.</p>
