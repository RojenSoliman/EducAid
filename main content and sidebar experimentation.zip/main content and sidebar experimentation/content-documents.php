<!-- content-documents.php -->
<h1>Documents</h1>
<p>Here you can manage all your uploaded documents. Ensure they are up-to-date for your application process.</p>
