<!-- content-profile.php -->
<h1>My Profile</h1>
<p>View and update your personal details here.</p>
<form>
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required><br>
    <input type="submit" value="Save">
</form>
