<!-- content-applications.php -->
<h1>Applications</h1>
<p>This section contains all the applications you have submitted. You can track the status of each application here.</p>
