<!-- content-logout.php -->
<h1>Logout</h1>
<p>You have been logged out. Thank you for using our service!</p>
